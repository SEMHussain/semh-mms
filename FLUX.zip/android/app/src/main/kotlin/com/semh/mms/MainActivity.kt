package com.semh.mms

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}